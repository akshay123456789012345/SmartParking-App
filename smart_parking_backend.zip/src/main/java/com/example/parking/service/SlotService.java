package com.example.parking.service;

import com.example.parking.model.Slot;
import com.example.parking.repository.SlotRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SlotService {

    private final SlotRepository repo;

    public SlotService(SlotRepository repo) {
        this.repo = repo;
    }

    public List<Slot> getAllSlots() {
        return repo.findAll();
    }

    public Slot addSlot(Slot slot) {
        return repo.save(slot);
    }

    public Slot bookSlot(String id) {
        Slot slot = repo.findById(id).orElseThrow();
        slot.setStatus("booked");
        return repo.save(slot);
    }

    public void deleteSlot(String id) {
        repo.deleteById(id);
    }
}
