package com.example.parking.controller;

import com.example.parking.model.Slot;
import com.example.parking.service.SlotService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/slots")
@CrossOrigin
public class SlotController {

    private final SlotService service;

    public SlotController(SlotService service) {
        this.service = service;
    }

    @GetMapping
    public List<Slot> getSlots() {
        return service.getAllSlots();
    }

    @PostMapping
    public Slot addSlot(@RequestBody Slot slot) {
        return service.addSlot(slot);
    }

    @PutMapping("/book/{id}")
    public Slot bookSlot(@PathVariable String id) {
        return service.bookSlot(id);
    }

    @DeleteMapping("/{id}")
    public void deleteSlot(@PathVariable String id) {
        service.deleteSlot(id);
    }
}
