package com.example.parking.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "slots")
public class Slot {

    @Id
    private String id;
    private String status;
    private double price;

    public Slot() {}

    public Slot(String status, double price) {
        this.status = status;
        this.price = price;
    }

    public String getId() { return id; }
    public String getStatus() { return status; }
    public double getPrice() { return price; }

    public void setStatus(String status) { this.status = status; }
    public void setPrice(double price) { this.price = price; }
}
