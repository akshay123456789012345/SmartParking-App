package com.example.parking.repository;

import com.example.parking.model.Slot;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SlotRepository extends MongoRepository<Slot, String> {
}
